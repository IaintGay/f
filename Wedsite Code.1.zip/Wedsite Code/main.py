from flask import Flask,render_template,redirect,url_for, session, request
from sqlite3 import *

conn=connect("index.db", check_same_thread = False)
c = conn.cursor()
c.execute("""
create table if not exists users(id integer primary key autoincrement, username text, password text)
""")
app=Flask(__name__)
app.secret_key = "sadflkjsefqe3"
database={"admin": "michael aint gay"}

@app.route("/")
def wow():
  return redirect(url_for("wowone"))
@app.route("/index.html")
def wowone():
  return render_template("index.html")

@app.route("/StartPlanning.html")
def wowtwo():
  return render_template("StartPlanning.html")

@app.route("/OurTeam.html")
def wowthree():
  return render_template("OurTeam.html")


@app.route("/ContactUs.html")
def wowfour():
  return render_template("ContactUs.html")

@app.route("/sitemap.html")
def wowfive():
  return render_template("sitemap.html")

@app.route("/day.html")
def wowsix():
  return render_template("day.html")

@app.route('/login.html', methods=["GET","POST"])
def wowseven():
  if request.method == "POST":
    usn = request.form["username"]
    pws = request.form["pwd"]
    user = c.execute("select * from users where username = ? and password = ?", (usn,pws)).fetchone()
    if user != None:
      session["username"] = user[1]
      session["loggedin"] = True
      return "LOGGED IN SUCCESSFULLY"
    else:
      return "BAD CREDENTIALS"
  else:
    return render_template("login.html")

@app.route('/signup.html', methods=["GET","POST"])
def woweight():
  if request.method == "POST":
    usn = request.form["username"]
    pws = request.form["pwd"]
    username = c.execute("select username from users where username = ?", (usn,)).fetchone()
    if username == None:
      c.execute("insert into users(username, password) values (?,?)", (usn,pws))
      conn.commit()
      return "SIGNED UP SUCCESSFULLY"
    else:
      return "THIS USERNAME IS ALREADY MADE"
  else:
    return render_template("signup.html")


app.run(port="3000", debug=True)
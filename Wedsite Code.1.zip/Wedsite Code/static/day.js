var day;

var endList = ""

function finDisp(){
  var inputCollect = window.document.getElementById('collect').value;
  endList.push(inputCollect.toString() + '<br>');
  
  window.document.getElementById('display').innerHTML= endList;
  document.getElementById('collect').value = '';
}

if (document.title === "Day") {



  day = localStorage.getItem("day");
  document.getElementById('myHeader').innerHTML = "May " + day + ", 2019";
}

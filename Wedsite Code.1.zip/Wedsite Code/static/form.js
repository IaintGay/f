if (document.title === "Day"){

  day=localStorage.getItem("form");
  document.getElementById("display").innerHTML= document.write(form)

}